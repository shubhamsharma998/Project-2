package Project;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.FloatWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class Answer1 {
	//mapper class
	public static class Map extends Mapper<LongWritable,Text,Text,FloatWritable>
	{
		public void map(LongWritable key,Text value, Context con) throws IOException, InterruptedException
		{
			String line= value.toString();
			String[] words=line.split("//s+ ");
			String s = words[1];
			Text outputkey = new Text (s.substring(0,4));
			float t = Float.parseFloat(words[7]);
			FloatWritable outputvalue = new FloatWritable(t);
			con.write(outputkey,outputvalue);
			
		}
		
	}
	
	//reducer class
	public static class Reduce extends Reducer<Text,FloatWritable,Text,FloatWritable>
	{
		public void reduce(Text word,Iterable<FloatWritable> values,Context con)throws IOException, InterruptedException
		{
			float maxtemp = (float)0;
			
		
	}
	public static void main(String[] args) throws IOException, ClassNotFoundException, InterruptedException {
		// TODO Auto-generated method stub
		Configuration c= new Configuration();
		Job j=Job.getInstance(c,"Ans1");
		j.setJarByClass(Answer1.class);
		j.setMapperClass(Map.class);
		j.setReducerClass(Reduce.class);
		j.setOutputKeyClass(Text.class);
		j.setOutputValueClass(IntWritable.class);
		FileInputFormat.addInputPath(j,new Path(args[0]));
		FileOutputFormat.setOutputPath(j,new Path(args[1]));
		System.exit(j.waitForCompletion(true)?0:1);
		
	}
	}
}
