package Project;

import java.io.IOException;
import java.util.LinkedHashMap;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.Reducer.Context;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;


public class Answer2 {
	
	//mapper class
		public static class Map extends Mapper<LongWritable,Text,Text,DoubleWritable>
		{
			public void map(LongWritable key,Text value, Context con) throws IOException, InterruptedException
			{
			String row = value.toString();
			String date = row.substring(6,14).replace(" ", " ");
			String tempHigh = row.substring(38, 45).replace(" ", " ");
			String tempLow = row.substring(38, 45).replace(" ", " ");
			
			double highest = Double.parseDouble(tempHigh);
			double lowest = Double.parseDouble(tempLow);
			
			if (lowest <10.0 && highest <35.0)
			con.write(new Text (date + "Cold Day "), new DoubleWritable(lowest));
			else if (highest > 35.0)
				con.write(new Text (date + "Hot Day "), new DoubleWritable(highest));
			}
		}
		
		//reducer class
		public static class Reduce extends Reducer<Text,DoubleWritable,Text,DoubleWritable>{
		public void setup(Context con)throws IOException, InterruptedException{
		con.write(new Text("Date Hot/Cold  Max Temp"), null);	
		}
		
	   public void reduce(Text text,Iterable<DoubleWritable>values,Context con)
			   throws IOException,InterruptedException{
		for (DoubleWritable value : values){
			double temp = value.get();
			if(temp !=-9999.0)
			con.write(text, new DoubleWritable(temp));
		}
			
		}

		}
		public static void main(String[] args) throws IOException, ClassNotFoundException, InterruptedException {
			// TODO Auto-generated method stub
			Configuration c= new Configuration();
			Job j=Job.getInstance(c,"Ans2");
			j.setJarByClass(Answer2.class);
			j.setMapperClass(Map.class);
			j.setReducerClass(Reduce.class);
			j.setOutputKeyClass(Text.class);
			j.setOutputValueClass(IntWritable.class);
			FileInputFormat.addInputPath(j,new Path(args[0]));
			FileOutputFormat.setOutputPath(j,new Path(args[1]));
			System.exit(j.waitForCompletion(true)?0:1);
			
		}
		

}
