package Project;

import java.io.IOException;
import java.util.LinkedHashMap;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.Reducer.Context;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;


public class Answer3 {
	//mapper class
		public static class Map extends Mapper<LongWritable,Text,Text,DoubleWritable>
		{
			public void map(LongWritable key,Text value, Context con) throws IOException, InterruptedException
			{
				
			String row = value.toString();
			String date = row.substring(6,14).replace(" ", " ");
			String temphigh = row.substring(38,45).replace(" ", " ");
			String templow =  row.substring(46,53).replace(" ", " ");
			
			double high = Double.parseDouble(temphigh);
			double low = Double.parseDouble(templow);
			
			if(low != -9999.0){
			con.write(new Text(date), new DoubleWritable(low));
			}
            if(high != -9999.0){
            	con.write(new Text(date), new DoubleWritable(high));
			}
			}
			
		}
		
		//reducer class
		public static class Reduce extends Reducer<Text,IntWritable,Text,DoubleWritable>
		{
			
		LinkedHashMap<DoubleWritable, Text>lowMap = new LinkedHashMap<DoubleWritable,Text>();
		LinkedHashMap<DoubleWritable, Text>highMap = new LinkedHashMap<DoubleWritable,Text>();
		int i =0;
		
		public void reduce(DoubleWritable key,Iterable<Text>values,Context con) throws IOException, InterruptedException
		{
		double temp = key.get();
		String date = values.iterator().next().toString();
		
		if(i<10)
		{
		lowMap.put(new DoubleWritable(temp), new Text(date));
		++i;
		}
        highMap.put(new DoubleWritable(temp), new Text (date));
        if(highMap.size()>10){
        	highMap.remove(highMap.keySet().iterator().next());
        }
		
		}
			
		
		public static void main(String[] args) throws IOException, ClassNotFoundException, InterruptedException {
			// TODO Auto-generated method stub
			Configuration c= new Configuration();
			Job j=Job.getInstance(c,"Ans3");
			j.setJarByClass(Answer3.class);
			j.setMapperClass(Map.class);
			j.setReducerClass(Reduce.class);
			j.setOutputKeyClass(Text.class);
			j.setOutputValueClass(IntWritable.class);
			FileInputFormat.addInputPath(j,new Path(args[0]));
			FileOutputFormat.setOutputPath(j,new Path(args[1]));
			System.exit(j.waitForCompletion(true)?0:1);
			
		}
		
		}
}
