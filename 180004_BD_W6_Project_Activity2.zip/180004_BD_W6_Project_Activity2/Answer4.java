package Project;

import java.io.IOException;
import java.util.Iterator;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.Reducer.Context;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;



public class Answer4 {
	//mapper class
		public static class Map extends Mapper<LongWritable,Text,Text,Text>
		{
			public void map(LongWritable key,Text value, Context con) throws IOException, InterruptedException
			{
				String line= value.toString();
				String[] words=line.split("//s+ ");
				String s = words[1];
				String max = words[7];
				String min = words[8];
				con.write(new  Text(s), new Text (max+"\t"+min));
			}
			
		}
		
		//reducer class
public static class Reduce extends Reducer<Text,Text,Text,Text>{
public void reduce(Text lines,Iterator<Text> values,Context con)throws IOException, InterruptedException{
	
				String output = values.next().toString();
				con.write(lines, new Text(output));
			}
			
		}
		public static void main(String[] args) throws IOException, ClassNotFoundException, InterruptedException {
			// TODO Auto-generated method stub
			Configuration c= new Configuration();
			Job j=Job.getInstance(c,"Ans4");
			j.setJarByClass(Answer4.class);
			j.setMapperClass(Map.class);
			j.setReducerClass(Reduce.class);
			j.setOutputKeyClass(Text.class);
			j.setOutputValueClass(IntWritable.class);
			FileInputFormat.addInputPath(j,new Path(args[0]));
			FileOutputFormat.setOutputPath(j,new Path(args[1]));
			System.exit(j.waitForCompletion(true)?0:1);
			
		}
		

}
